# Core Working Group
* [Ravi Prakash](#TODO)
* [Pramod Varma](#TODO)
* [Sujith Nair](#TODO)
* [Nirmal Rajeevan](#TODO)
* [Venkataraman Mahadevan](#TODO)
* [Paul Kapustin](#TODO)

# Mobility Working Group
* [Sujith Nair](#TODO)
* [Ravi Prakash](#TODO)
* [Srikanth Chunduri](#TODO)
* [Nirmal Rajeevan](#TODO)
* [Nikith Shetty](#TODO)
* [Paul Kapustin](#TODO)
* [Oleg Romashin](#TODO)

# Retail Working Group
* [Venkatraman Mahadevan](#TODO)
* [Thejesh GN](#TODO)
* [Ashok Ayengar](#TODO)
* [Akshay Mathur](#TODO)

# Logistics Working Group
* [Oleg Romashin](#TODO)
* [Paul Kapustin](#TODO)
* [Nikith Shetty](#TODO)

# Infrastructure Working Group
* [Dhiraj Patorkar](#TODO)
* [Devendra Rane](#TODO)
* [Sujeet Suryavanshi](#TODO)
* [Nikith Shetty](#TODO)
* [Dharmesh Bajpai](#TODO)

# Network Security Working Group
* [Sasi Kumar Ganesan](#TODO)
* [Venkataraman Mahadevan](#TODO)
* [Ravi Prakash](#TODO)
